<?php

require_once('framework/yii.php');
require_once('yaamp/include.php');

$app = Yii::createWebApplication('yaamp/config.php');


