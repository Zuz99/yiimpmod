/* Yiimp Theme + Sidebar (UI only) */
(function(){
  var THEME_KEY = 'yiimp_theme';
  var defaultTheme = 'red-dark';

  function applyTheme(theme){
    try{
      document.documentElement.setAttribute('data-theme', theme);
    }catch(e){}
  }

  function getSavedTheme(){
    try{
      return localStorage.getItem(THEME_KEY) || '';
    }catch(e){
      return '';
    }
  }

  function saveTheme(theme){
    try{
      localStorage.setItem(THEME_KEY, theme);
    }catch(e){}
  }

  function initThemeSelect(){
    var selects = document.querySelectorAll('[data-theme-select]');
    if(!selects || !selects.length) return;

    var saved = getSavedTheme();
    var theme = saved || defaultTheme;
    applyTheme(theme);

    selects.forEach(function(sel){
      sel.value = theme;
      sel.addEventListener('change', function(){
        var t = sel.value || defaultTheme;
        applyTheme(t);
        saveTheme(t);
        // keep all selects in sync
        selects.forEach(function(other){ other.value = t; });
      });
    });
  }

  function initSidebar(){
    var btn = document.getElementById('sidebarToggle');
    var backdrop = document.getElementById('appBackdrop');
    if(btn){
      btn.addEventListener('click', function(){
        document.body.classList.toggle('sidebar-open');
      });
    }
    if(backdrop){
      backdrop.addEventListener('click', function(){
        document.body.classList.remove('sidebar-open');
      });
    }
    // close sidebar on escape
    document.addEventListener('keydown', function(e){
      if(e.key === 'Escape'){
        document.body.classList.remove('sidebar-open');
      }
    });
  }

  document.addEventListener('DOMContentLoaded', function(){
    // Apply early if possible
    var saved = getSavedTheme();
    applyTheme(saved || defaultTheme);
    initThemeSelect();
    initSidebar();
  });
})();
